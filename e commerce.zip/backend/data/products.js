const products = [
  {
    name: 'Écouteurs sans fil Bluetooth Airpods',
    image: 'https://via.placeholder.com/300x200?text=Airpods',
    description:
      'La technologie Bluetooth vous permet de le connecter sans fil à des appareils compatibles. Le son AAC de haute qualité offre une expérience d\'écoute immersive. Le microphone intégré vous permet de prendre des appels tout en travaillant.',
    brand: 'Apple',
    category: 'Électronique',
    price: 89.99,
    countInStock: 10,
    rating: 4.5,
    numReviews: 12,
  },
  {
    name: 'iPhone 11 Pro 256 Go',
    image: 'https://via.placeholder.com/300x200?text=iPhone+11+Pro',
    description:
      'Découvrez l\'iPhone 11 Pro. Un système de triple caméra révolutionnaire qui ajoute des fonctionnalités sans complexité. Un bond en avant sans précédent en matière de durée de batterie.',
    brand: 'Apple',
    category: 'Électronique',
    price: 599.99,
    countInStock: 7,
    rating: 4.0,
    numReviews: 8,
  },
  {
    name: 'Appareil photo reflex numérique Canon EOS 80D',
    image: 'https://via.placeholder.com/300x200?text=Canon+EOS+80D',
    description:
      'Caractérisé par des spécifications d\'imagerie polyvalentes, le Canon EOS 80D se distingue encore davantage grâce à une paire de systèmes de mise au point robustes et une conception intuitive.',
    brand: 'Canon',
    category: 'Électronique',
    price: 929.99,
    countInStock: 5,
    rating: 3,
    numReviews: 12,
  },
  {
    name: 'Console de jeu Sony Playstation 4 Pro version blanche',
    image: 'https://via.placeholder.com/300x200?text=Playstation+4+Pro',
    description:
      'Le centre de divertissement à domicile ultime commence avec la PlayStation. Que vous soyez un joueur, que vous aimiez les films HD, la télévision ou la musique.',
    brand: 'Sony',
    category: 'Électronique',
    price: 399.99,
    countInStock: 11,
    rating: 5,
    numReviews: 12,
  },
  {
    name: 'Souris de jeu Logitech série G',
    image: 'https://via.placeholder.com/300x200?text=Souris+Logitech+G',
    description:
      'Obtenez une meilleure prise en main de vos jeux avec cette souris de jeu Logitech LIGHTSYNC. Les six boutons programmables permettent une personnalisation pour une expérience de jeu fluide.',
    brand: 'Logitech',
    category: 'Électronique',
    price: 49.99,
    countInStock: 7,
    rating: 3.5,
    numReviews: 10,
  },
  {
    name: 'Amazon Echo Dot 3ème génération',
    image: 'https://via.placeholder.com/300x200?text=Echo+Dot+3',
    description:
      "Rencontrez Echo Dot - notre haut-parleur intelligent le plus populaire avec un design en tissu. C'est notre haut-parleur intelligent le plus compact qui s'adapte parfaitement aux petits espaces.",
    brand: 'Amazon',
    category: 'Électronique',
    price: 29.99,
    countInStock: 0,
    rating: 4,
    numReviews: 12,
  },
];

export default products;
